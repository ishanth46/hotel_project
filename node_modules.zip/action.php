<?php

ob_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // extract($_POST);
    extract($_POST);

    // Determine source page
    // $source = isset($_POST['source']) ? $_POST['source'] : '';

    // if ($source == 'index') {
    //     $url = "index.php";
    // } elseif ($source == 'eldercare') {
    //     $url = "elder-care-services-in-medavakkam-chennai.php";
    // } elseif ($source == 'retirement') {
    //     $url = "retirement-homes-in-medavakkam-chennai.php";
    // } else {
    //     $url = "index.php"; // fallback
    // }

    $source = isset($_POST['source']) ? $_POST['source'] : 'index';

    $pageMap = [
        'index' => 'index.php',
    ];

    // Use fallback to 'index.php' if key doesn't exist
    $url = isset($pageMap[$source]) ? $pageMap[$source] : 'index.php';



    // $url = "index.php";

    $to = "rohaanhotels@gmail.com";
    $cc = "";
    $bcc = "";

    $subject = "Appointment Booked for Rohaan Hotel";

    $mail_html = '<div style="background:#004875"; padding: 50px 24px;">

    <div style="width: 650px; margin:auto; background: #FFFFFF; padding: 25px;">
        <table border="0" width="70%" align="center" style="font-family: Arial">
            <tr>
                <td colspan="3" align="center" style="font-size: 24px;">' . $subject . '<br><br><br></td>
            </tr>
            <tr>
                <td width="50%"><b>Name</b></td>
                <td>:</td>
                <td>' . $name . '</td>
            </tr>
            <tr>
                <td><b>Email</b></td>
                <td>:</td>
                <td>' . $email . '</td>
            </tr>
            <tr>
                <td><b>Phone</b></td>
                <td>:</td>
                <td>' . $phone . '</td>
            </tr>
            <tr>
                <td><b>Subject</b></td>
                <td>:</td>
                <td>' . $subject . '</td>
            </tr>
            <tr>
                <td><b>Location</b></td>
                <td>:</td>
                <td>' . $location . '</td>
            </tr>';

    $mail_html .= ' </table>
		<br><br>
		<div style="padding-top: 20px; padding-bottom: 20px; margin-top: 25px; border-top: 1px solid #CDCDCD; font-family: Arial">
			<center>Copyright &copy; ' . date("Y") . ' www.rohaanhotels.com</center>
		</div>
    </div>
	
    </div>';

    $file = "";

    // echo $mail_html;
    echo "Source: " . $_POST['source'];
    // exit;

    include 'mailer/function.php';

    if (shoot_mailer($to, $cc, $bcc, $subject, $mail_html, $file)) {
        //echo 1;
        //header("Location: https://techappsconsulting.in/contact.php?msg=success");
        header("Location: $url");

        // header("Location: $url?msg=success#contactform");
    } else {
        //echo 0;
        //header("Location: https://techappsconsulting.in/contact.php?msg=failed");
        header("Location: $url?msg=failed#contactform");

    }

}

?>