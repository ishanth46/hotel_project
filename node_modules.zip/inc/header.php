<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Rohaan Hotels</title>
    <!-- favicon  -->
    <!-- <link rel="icon" href="https://rohaan/favicon.ico" type="image/x-icon">
    <link rel="shortcut icon" href="https://rohaanseniorcare.com/favicon.ico" type="image/x-icon"> -->

    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
        integrity="sha512-y...YOUR_HASH..." crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="../css/output.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">

    <!-- fonts  -->
    <link href="https://fonts.googleapis.com/css2?family=Lora&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Lora&family=Poppins:wght@400;700&display=swap"
        rel="stylesheet">

    <!-- swiper cdn  -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css" />

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Bootstrap (required for Ekko) -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Ekko Lightbox -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/js/bootstrap.min.js"></script>

</head>
<!-- Before </body> -->
<script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>

<body>
    <!-- navbar  -->
    <nav class="p-4 max-w-[1600px] mx-auto">
        <div class="flex justify-between items-center">
            <div class="flex items-center pl-8">
                <img src="../assets/rohanlogo.png" alt="Rohaan-hotel-logo">
            </div>

            <!-- Hamburger / Close -->
            <div class="md:hidden absolute right-8 z-50">
                <button onclick="toggleMenu()" class="text-[#009CFF] focus:outline-none">
                    <i class="fas fa-bars text-2xl" id="bars"></i>
                    <i class="fas fa-times text-2xl hidden" id="close"></i>
                </button>
            </div>

            <!-- NAVIGATION - LARGE SCREENS -->
            <div class="hidden md:flex ">
                <ul class="hidden md:flex justify-between w-[600px]">
                    <li class="text-base pr-8">
                        <a href="index.php"
                            class="transition duration-300 focus:outline-none focus:text-[#004875] focus:underline hover:underline hover:text-[#009CFF]"
                            style="text-underline-offset: 8px;">HOME</a>
                    </li>
                    <li class="text-base pr-8">
                        <a href="#about"
                            class="transition duration-300 focus:outline-none focus:text-[#004875] focus:underline hover:underline hover:text-[#009CFF]"
                            style="text-underline-offset: 8px;">ABOUT US</a>
                    </li>
                    <li class="text-base pr-8">
                        <a href="#locations"
                            class="transition duration-300 focus:outline-none focus:text-[#004875] focus:underline hover:underline hover:text-[#009CFF]"
                            style="text-underline-offset: 8px;">LOCATIONS</a>
                    </li>
                    <li class="text-base pr-8">
                        <a href="#rooms"
                            class="transition duration-300 focus:outline-none focus:text-[#004875] focus:underline hover:underline hover:text-[#009CFF]"
                            style="text-underline-offset: 8px;">ROOM</a>
                    </li>
                    <li class="text-base pr-8">
                        <a href="#contactus"
                            class="transition duration-300 focus:outline-none focus:text-[#004875] focus:underline hover:underline hover:text-[#009CFF]"
                            style="text-underline-offset: 8px;">CONTACT US</a>
                    </li>
                </ul>
            </div>

            <div class="hidden md:flex">
                <button
                    class="bg-[#009CFF] text-white py-2 px-4 rounded hover:bg-[#004875] outline-none project-brochure-button"
                    onclick="openForm()">BOOK
                    NOW</button>
            </div>

        </div>

        <!-- MOBILE MENU -->
        <div id="mobileMenu" class="hidden flex w-full mx-auto py-8 text-center flex-col items-center bg-gray-100 mt-4">
            <a href="#"
                class="block text-gray-800 cursor-pointer py-3 transition duration-300 focus:outline-none focus:text-yellow-500 focus:underline hover:underline hover:text-yellow-500"
                style="text-underline-offset: 8px;">Home</a>
            <a href="#about"
                class="block text-gray-800 cursor-pointer mt-1 py-3 transition duration-300 focus:outline-none focus:text-yellow-500 focus:underline hover:underline hover:text-yellow-500"
                style="text-underline-offset: 8px;">About</a>
            <a href="#locations"
                class="block text-gray-800 cursor-pointer mt-1 py-3 transition duration-300 focus:outline-none focus:text-yellow-500 focus:underline hover:underline hover:text-yellow-500"
                style="text-underline-offset: 8px;">Locations</a>
            <a href="#rooms"
                class="block text-gray-800 cursor-pointer mt-1 py-3 transition duration-300 focus:outline-none focus:text-yellow-500 focus:underline hover:underline hover:text-yellow-500"
                style="text-underline-offset: 8px;">ROOM</a>
            <a href="#contactus"
                class="block text-gray-800 cursor-pointer mt-1 py-3 transition duration-300 focus:outline-none focus:text-yellow-500 focus:underline hover:underline hover:text-yellow-500"
                style="text-underline-offset: 8px;">Contact Us</a>
        </div>
    </nav>
        
    </body>
    </html>