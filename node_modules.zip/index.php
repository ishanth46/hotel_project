<?php include("inc/header.php") ?>

<body>
    <!-- hero section  -->
    <section
        class="max-w-[1600px] mx-auto bg-[url(../assets/mobile-banner.png)] h-[305px] md:h-[512px] md:bg-[url(../assets/banner-bg.png)]  bg-cover bg-center px-8 md:px-12 py-[5px] md:py-[120px] ">
        <div class="max-w-3xl text-left text-white  md:pl-8 flex flex-col pt-8 md:pt-0">
            <h1 class="font-medium uppercase mb-4 font-lora text-xl md:text-[40px] leading-[1.5] md:leading-[1.3]">
                Business Class Hotel in Chennai,
                Medavakkam & Ashoka Nagar - Rohaan Hotels
            </h1>

            <button onclick="openForm()"
                class="project-brochure-button bg-[#ffff]  rounded-md font-medium w-[100px] md:w-[165px] text-[#004875]  text-sm md:text-base py-2 px-2 md:px-4 md:mt-5 focus:outline-none focus:ring-0 outline-none outline-0 outline-offset-0 animated-button victoria-two ">
                BOOK NOW
            </button>

            <!-- <button
                class="bg-[#0D76B8] hover:bg-[#004875] rounded-md transition-all duration-200">BOOK
                NOW</button> -->

        </div>
    </section>


    <!-- Popup Form -->
    <div id="popupForm" class="form-popup">
        <form class="form-container" method="post" action="action.php">
            <button type="button" class="btn cancel" onclick="closeForm()"><span class="close-x">X</span></button>
            <input name="name" type="text" placeholder="Enter your Name">
            <input name="email" type="email" placeholder="Enter your Email">
            <input name="phone" type="number" placeholder="Enter your Phone Number">
            <input name="msg" class="contact-message" type="text" placeholder="Add a Message">
            <input class="contact-submit" type="submit" value="Submit">
        </form>
    </div>
    <!-- Popup Form ends -->


    <!-- calender  -->
    <section class="max-w-6xl mx-auto shadow-md  relative  relative top-0 md:top-[-80px] bg-white p-4 mt-8">
        <div class="border border-[#009DFE]  px-12 py-6">
            <div>
                <form class="grid grid-cols-1 md:grid-cols-4 gap-4 items-end relative calender-form">
                    <!-- Name -->
                    <div class="flex flex-col">
                        <label for="name" class=" text-sm font-medium">Name</label>
                        <input type="text" name="name"
                            class="bg-transparent border-b border-gray-500 text-black text-sm focus:outline-none focus:border-lime-400 py-2 px-1 placeholder-grey-100"
                            placeholder=" Enter your name">
                    </div>

                    <!-- Phone -->
                    <div class="flex flex-col">
                        <label for="phone" class=" text-sm font-medium">Phone</label>
                        <input type="tel" id="phone" name="phone"
                            class="bg-transparent border-b border-gray-500 text-black text-sm focus:outline-none focus:border-lime-400 py-2 px-1 placeholder-grey-100"
                            placeholder=" Enter your phone number">
                    </div>


                    <!-- Email -->
                    <div class="flex flex-col">
                        <label for="email" class=" text-sm font-medium">Email</label>
                        <input type="email" id="email" name="email"
                            class="bg-transparent border-b border-gray-500 text-black text-sm focus:outline-none focus:border-lime-400 py-2 px-1 placeholder-grey-100"
                            placeholder=" Enter your email address">
                    </div>

                    <!-- Location -->
                    <div class="flex flex-col">
                        <label for="location" class="mb-1 text-sm font-medium">Location</label>
                        <select id="location" name="location"
                            class="bg-transparent border-b border-gray-500 text-black text-sm focus:outline-none focus:border-lime-400 py-2 px-1 appearance-none">
                            <option value="01" selected>Medavakkam</option>
                            <option value="02">Ashoka Nagar</option>
                            <option value="03">Perumbakkam</option>
                        </select>
                    </div>

                    <!-- Check In -->
                    <div class="flex flex-col">
                        <label for="checkin" class="mb-1 text-sm font-medium">Check In</label>
                        <input type="date" id="checkin" name="checkin"
                            class="bg-transparent border-b border-gray-500 text-black text-sm focus:outline-none focus:border-lime-400 py-2 px-1 placeholder-white"
                            placeholder="mm/dd/yyyy">
                    </div>

                    <!-- Check Out -->
                    <div class="flex flex-col">
                        <label for="checkout" class="mb-1 text-sm font-medium">Check Out</label>
                        <input type="date" id="checkout" name="checkout"
                            class="bg-transparent border-b border-gray-500 text-black text-sm focus:outline-none focus:border-lime-400 py-2 px-1 placeholder-white"
                            placeholder="mm/dd/yyyy">
                    </div>

                    <!-- Adults -->
                    <div class="flex flex-col">
                        <label for="adults" class="mb-1 text-sm font-medium">Adults</label>
                        <select id="adults" name="adults"
                            class="bg-transparent border-b border-gray-500 text-black text-sm focus:outline-none focus:border-lime-400 py-2 px-1 appearance-none">
                            <option value="01" selected>01</option>
                            <option value="02">02</option>
                            <option value="03">03</option>
                            <option value="04">04</option>
                        </select>
                    </div>

                    <!-- Children -->
                    <div class="flex flex-col">
                        <label for="children" class="mb-1 text-sm font-medium">Children</label>
                        <select id="children" name="children"
                            class="bg-transparent border-b border-gray-500 text-black text-sm focus:outline-none focus:border-lime-400 py-2 px-1 appearance-none">
                            <option value="00" selected>00</option>
                            <option value="01">01</option>
                            <option value="02">02</option>
                            <option value="03">03</option>
                        </select>
                    </div>
                    <br>
                    <!-- Search Button -->
                    <div
                        class="bg-[#0D76B8] hover:bg-[#004875] rounded-md transition-all duration-200 py-2 px-2 md:absolute md:b-0 md:left-[40%] w-[200px]">
                        <button type="submit"
                            class="w-full  border border-white  text-white font-semibold py-2 px-2 focus:outline-none focus:ring-0 outline-none outline-0 outline-offset-0  project-brochure-button"
                            onclick="openForm()">
                            SUBMIT
                        </button>
                    </div>
                </form>
            </div>

        </div>
    </section>


    <!-- g reviews  -->
    <div class="max-w-xl md:max-w-7xl mx-auto p-4 md:p-0 md:mt-[-50px]">
        <script src="https://static.elfsight.com/platform/platform.js" async></script>
        <div class="elfsight-app-7b885646-e05a-4b1f-900f-89ca0b789fe2" data-elfsight-app-lazy></div>
        <!-- <div id="featurable-67c7a980-96db-4b04-9f63-af7fbf7fe5b9" data-featurable-async></div>
        <script src="https://featurable.com/assets/v2/carousel_default.min.js" defer charset="UTF-8"></script> -->

    </div>
    <!-- <script defer async src='https://cdn.trustindex.io/loader.js?1068f3b5171a055edc266d1f09c'></script> -->


    <!-- about us section -->
    <section id="about"
        class="max-w-[1540px] bg-[url(../assets/about-bg.png)] bg-cover bg-center  mx-auto flex flex-col  justify-between md:flex-row gap-8  bg-white p-[5%] mobile-text-center">
        <div class="max-w-xl mx-auto  ">
            <h2 class="text-[#004875] text-xl  md:text-3xl  font-lora leading-[1.5] ">Welcome to Rohaan Hotels – Where
                <br> Comfort
                Meets Convenience
            </h2>

            <p class="py-4 text-sm  md:text-base">If you're looking for a business class hotel in Chennai, Rohaan Hotels
                offers the
                perfect blend of luxury
                and affordability. We are strategically located across Medavakkam, Ashoka Nagar, and nearby areas,
                catering to both business professionals and families. Our properties are also ideal for those seeking
                budget hotels in Chennai with top-class service. </p>
            <p class="py-4 text-sm  md:text-base">We are proud to be recognized as one of the top business class hotels
                in
                Medavakkam and business class
                hotels in Ashoka Nagar, and a preferred choice among budget hotels in Medavakkam for short and long
                stays.</p>
        </div>
        <div class="max-w-xl mx-auto relative">
            <img src="../assets/about-1-img.png" alt="Rohaan Hotels">
            <img src="../assets/about-2-img.png" class="absolute left-[-4%] md:left-[-15%] top-[70%]"
                alt="Rohaan Hotels">
            <img src="../assets/line-rectangle.png" class="absolute right-[-3%] top-[91%]" alt="Rohaan Hotels">
        </div>
    </section>

    <!-- Medavakkam location slider  -->
    <section id="locations" class="max-w-8xl mx-auto p-8 mt-[80px] md:mt-0">
        <div class="flex items-center justify-center ">
            <span><img src="../assets/line1.png" alt="line-vector"></span>
            <h2 class="px-4 font-lora text-xl  md:text-3xl text-center text-[#004875]">Hotel Locations</h2>
            <span><img src="../assets/Line2.png" alt="line-vector"></span>
        </div>
        <div
            class="w-[350px] md:w-[1200px] mx-auto flex flex-col md:flex-row space-y-2 justify-center md:space-x-[100px] items-center mt-4 mobile-text-center">
            <div class="w-[200px] md:w-[400px] md:text-right relative">
                <span class=" hidden md:block "><img src="../assets/vector-line-3.png"
                        class="absolute right-[40%] top-[-26%] w-[30px] h-[30px]" alt="vectors"></span>
                <h3 class="text-xl md:text-3xl font-bold font-lora">Medavakkam</h3>
                <span class=" hidden md:block "><img src="../assets/vector-right-lines.png"
                        class="absolute right-[-4%] top-[46%] w-[30px] h-[30px" alt="vectors"></span>
            </div>
            <div class="w-[300px] md:w-[600px] text-left">
                <p class="mobile-text-center md:text-left">Rohaan Hotel Medavakkam offers a business class hotel stay
                    experience in one of South Chennai’s
                    fastest growing localities. Ideally suited for professionals, families, and medical visitors, our
                    hotel combines contemporary design with comfort. As a leading business class hotel in Medavakkam, we
                    offer easy access to the IT corridors of OMR and Sholinganallur, making it perfect for corporate
                    stays.
                </p>
            </div>
        </div>
    </section>

    <!-- slider section  -->
    <section class="max-w-[1400px] mx-auto base-template">
        <div class="base-template__wrapper wrapper">
            <div class="base-template__content">
                <div class="booking-slider">
                    <!-- Slider Navigation -->
                    <div class="booking-slider__nav slider-nav">
                        <div title="Newest offers" tabindex="0" class="slider-nav__item slider-nav__item_prev">
                            <svg width="16" height="28" viewBox="0 0 16 28" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M14 26L2 14L14 2" stroke="white" stroke-width="4" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>
                        </div>
                        <div title="Oldest offers" tabindex="0" class="slider-nav__item slider-nav__item_next">
                            <svg width="16" height="28" viewBox="0 0 16 28" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M2 26L14 14L2 2" stroke="white" stroke-width="4" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>
                        </div>
                    </div>

                    <!-- Slider Content -->

                    <div class="booking-slider__slider swiper">
                        <div class="booking-slider__wrapper swiper-wrapper">
                            <!-- Slider: Slide 1 -->
                            <div class="booking-slider__slide swiper-slide">
                                <div class="booking-slider__item booking-slider-item">
                                    <a title="Luxury Detached Home in Bournemouth" href="/"
                                        class="booking-slider-item__image" onclick="event.preventDefault();">
                                        <img src="../assets/bedroom-rohaan.png" alt="Hotels in Medavakkam" />
                                    </a>
                                    <div class="booking-slider-item__content">
                                        <h2 class="booking-slider-item__title">
                                            <a title="Hotels in Medavakkam" href="/" onclick="event.preventDefault();">
                                                Deluxe Double Room
                                            </a>
                                        </h2>
                                        <div class="booking-slider-item__text">
                                            Enjoy a refined stay in our Deluxe Double Room with air-conditioned rooms,
                                            featuring an array of amenities designed to ensure maximum comfort and ease
                                            throughout your visit.
                                        </div>

                                        <div class="py-4">
                                            <img src="../assets/black-line.png" alt="black-line-vector" />
                                        </div>

                                        <div class="booking-slider-item__footer">
                                            <div class="booking-slider-item__footer-inner">
                                                <div class="booking-slider-item__amenities grid grid-cols-2">
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/queensizebed.png" alt="queensizebed" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Queen Size 170
                                                            Sq.ft</div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/digitalsafe.png" alt="digitalsafe" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Digital Safe
                                                        </div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/hotwater.png" alt="hotwater" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">24x7 hot water
                                                        </div>
                                                    </div>
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/airconditioner.png"
                                                                alt="airconditioner" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Air conditioner
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="py-4">
                                                    <img src="../assets/black-line.png" alt="black-line-vector" />
                                                </div>
                                                <div class="flex  items-center justify-between">
                                                    <div>
                                                        <a class="booking-slider-item__btn" href="/"
                                                            onclick="event.preventDefault();">
                                                            <span class="booking-slider-item__btn-text">Book Now</span>
                                                            <span class="booking-slider-item__btn-icon"></span>
                                                        </a>
                                                    </div>
                                                    <div>
                                                        <p class="text-[#004875] font-bold text-xl">₹2,500 / Night</p>

                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Slider: Slide 2 -->

                            <div class="booking-slider__slide swiper-slide">
                                <div class="booking-slider__item booking-slider-item">


                                    <a title="Luxury Detached Home in Bournemouth" href="/"
                                        class="booking-slider-item__image" onclick="event.preventDefault();">
                                        <img src="../assets/double-bedroom-with-breakfast.png"
                                            alt="Hotels in Medavakkam" />
                                    </a>

                                    <div class="booking-slider-item__content">
                                        <!-- <div class="booking-slider-item__price">
                                            £3,500<small>/month</small>
                                        </div> -->

                                        <h2 class="booking-slider-item__title">
                                            <a title="Hotels in Medavakkam" href="/" onclick="event.preventDefault();">
                                                Deluxe Double Room with breakfast
                                            </a>
                                        </h2>

                                        <!-- <div title="Address" class="booking-slider-item__address">
                                            <span class="booking-slider-item__address-icon">
                                                <img src="https://bato-web-agency.github.io/bato-shared/img/slider-2/icon-address.svg"
                                                    alt="Address" />
                                            </span>
                                            29 Terrace Rd, BH2 5EL
                                        </div> -->

                                        <div class="booking-slider-item__text">
                                            Start your day right in our Deluxe Double room with a delicious breakfast
                                            and an array of amenities thoughtfully designed for your perfect stay.
                                        </div>

                                        <div class="py-4">
                                            <img src="../assets/black-line.png" alt="black-line-vector" />
                                        </div>

                                        <div class="booking-slider-item__footer">
                                            <div class="booking-slider-item__footer-inner">
                                                <div class="booking-slider-item__amenities grid grid-cols-2">
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/queensizebed.png" alt="queensizebed" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Queen Size 170
                                                            Sq.ft</div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/digitalsafe.png" alt="digitalsafe" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Digital Safe
                                                        </div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/hotwater.png" alt="hotwater" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">24x7 hot water
                                                        </div>
                                                    </div>
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/airconditioner.png"
                                                                alt="airconditioner" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Air conditioner
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="py-4">
                                                    <img src="../assets/black-line.png" alt="black-line-vector" />
                                                </div>
                                                <div class="flex  items-center justify-between">
                                                    <div>
                                                        <a class="booking-slider-item__btn" href="/"
                                                            onclick="event.preventDefault();">
                                                            <span class="booking-slider-item__btn-text">Book Now</span>
                                                            <span class="booking-slider-item__btn-icon"></span>
                                                        </a>
                                                    </div>
                                                    <div>
                                                        <p class="text-[#004875] font-bold text-xl">₹2,700 / Night</p>

                                                    </div>
                                                </div>

                                            </div>
                                        </div>



                                    </div>
                                </div>
                            </div>

                            <!-- Slider: Slide 3 -->

                            <div class="booking-slider__slide swiper-slide">
                                <div class="booking-slider__item booking-slider-item">
                                    <!-- <div title="The most popular option" class="booking-slider-item__badge">
                                        Popular
                                    </div> -->

                                    <a title="Luxury Detached Home in Bournemouth" href="/"
                                        class="booking-slider-item__image" onclick="event.preventDefault();">
                                        <img src="../assets/twin-room.png" alt="Hotels in Medavakkam" />
                                    </a>

                                    <div class="booking-slider-item__content">
                                        <!-- <div class="booking-slider-item__price">
                                            £3,500<small>/month</small>
                                        </div> -->

                                        <h2 class="booking-slider-item__title">
                                            <a title="Hotels in Medavakkam" href="/" onclick="event.preventDefault();">
                                                Deluxe Twin Room
                                            </a>
                                        </h2>

                                        <!-- <div title="Address" class="booking-slider-item__address">
                                            <span class="booking-slider-item__address-icon">
                                                <img src="https://bato-web-agency.github.io/bato-shared/img/slider-2/icon-address.svg"
                                                    alt="Address" />
                                            </span>
                                            29 Terrace Rd, BH2 5EL
                                        </div> -->

                                        <div class="booking-slider-item__text">
                                            Enjoy the perfect blend of comfort and convenience in our twin room, with
                                            two comfortable beds and amenities to refresh and revitalise.
                                        </div>

                                        <div class="py-4">
                                            <img src="../assets/black-line.png" alt="black-line-vector" />
                                        </div>

                                        <div class="booking-slider-item__footer">
                                            <div class="booking-slider-item__footer-inner">
                                                <div class="booking-slider-item__amenities grid grid-cols-2">
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/twin-bedroom.png" alt="twin-bedroom" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Twin Beds 150
                                                            Sq.ft</div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/digitalsafe.png" alt="digitalsafe" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Digital Safe
                                                        </div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/hotwater.png" alt="hotwater" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">24x7 hot water
                                                        </div>
                                                    </div>
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/airconditioner.png"
                                                                alt="airconditioner" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Air conditioner
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="py-4">
                                                    <img src="../assets/black-line.png" alt="black-line-vector" />
                                                </div>
                                                <div class="flex  items-center justify-between">
                                                    <div>
                                                        <a class="booking-slider-item__btn" href="/"
                                                            onclick="event.preventDefault();">
                                                            <span class="booking-slider-item__btn-text">Book Now</span>
                                                            <span class="booking-slider-item__btn-icon"></span>
                                                        </a>
                                                    </div>
                                                    <div>
                                                        <p class="text-[#004875] font-bold text-xl">₹2,850/ Night</p>

                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Slider: Slide 4 -->
                            <div class="booking-slider__slide swiper-slide">
                                <div class="booking-slider__item booking-slider-item">
                                    <!-- <div title="The most popular option" class="booking-slider-item__badge">
                                        Popular
                                    </div> -->

                                    <a title="Luxury Detached Home in Bournemouth" href="/"
                                        class="booking-slider-item__image" onclick="event.preventDefault();">
                                        <img src="../assets/twin-bedroom-with-breakfast.png"
                                            alt="Hotels in Medavakkam" />
                                    </a>

                                    <div class="booking-slider-item__content">
                                        <!-- <div class="booking-slider-item__price">
                                            £3,500<small>/month</small>
                                        </div> -->

                                        <h2 class="booking-slider-item__title">
                                            <a title="Hotels in Medavakkam" href="/" onclick="event.preventDefault();">
                                                Deluxe Twin Room With breakfast
                                            </a>
                                        </h2>

                                        <!-- <div title="Address" class="booking-slider-item__address">
                                            <span class="booking-slider-item__address-icon">
                                                <img src="https://bato-web-agency.github.io/bato-shared/img/slider-2/icon-address.svg"
                                                    alt="Address" />
                                            </span>
                                            29 Terrace Rd, BH2 5EL
                                        </div> -->

                                        <div class="booking-slider-item__text">
                                            Enjoy the perfect blend of comfort and convenience in our twin room, with
                                            two comfortable beds and amenities to refresh and revitalise.
                                        </div>

                                        <div class="py-4">
                                            <img src="../assets/black-line.png" alt="black-line-vector" />
                                        </div>

                                        <div class="booking-slider-item__footer">
                                            <div class="booking-slider-item__footer-inner">
                                                <div class="booking-slider-item__amenities grid grid-cols-2">
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/twin-bedroom.png" alt="queensizebed" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Twin Beds 150
                                                            Sq.ft</div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/digitalsafe.png" alt="digitalsafe" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Digital Safe
                                                        </div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/hotwater.png" alt="hotwater" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">24x7 hot water
                                                        </div>
                                                    </div>
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/airconditioner.png"
                                                                alt="airconditioner" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Air conditioner
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="py-4">
                                                    <img src="../assets/black-line.png" alt="black-line-vector" />
                                                </div>
                                                <div class="flex  items-center justify-between">
                                                    <div>
                                                        <a class="booking-slider-item__btn" href="/"
                                                            onclick="event.preventDefault();">
                                                            <span class="booking-slider-item__btn-text">Book Now</span>
                                                            <span class="booking-slider-item__btn-icon"></span>
                                                        </a>
                                                    </div>
                                                    <div>
                                                        <p class="text-[#004875] font-bold text-xl">₹3,000/ Night</p>

                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <!-- Slider Pagination -->

                    <div class="booking-slider__pagination slider-pagination"></div>
                </div>
                <div class="max-w-6xl px-2 md:px-0 px-2 md:px-0  mx-auto text-center mt-8 mb-8 mobile-text-center">
                    <p>For travelers seeking a budget hotel in Medavakkam without compromising on quality, Rohaan
                        provides clean, well equipped rooms, high-speed Wi-Fi, and 24/7 support. The location is close
                        to Global Hospital, educational institutions, and shopping hubs, making it one of the most
                        preferred budget hotels in Chennai for short and extended stays.</p>
                    <div
                        class="max-w-sm mx-auto flex flex-col md:flex-row space-y-5 md:space-y-0 items-center justify-between mt-8 ">
                        <button
                            class="bg-[#009CFF] text-white px-8 py-2 uppercase text-base font-semibold outline-none animated-button victoria-one">Read
                            more</button>
                      <a href="https://www.google.com/maps/place/Rohaan+Hotels+Medavakkam+by+UPAR/@12.9093978,80.1942302,17z/data=!4m9!3m8!1s0x3a525dddafbf6983:0x313f72403e08ee91!5m2!4m1!1i2!8m2!3d12.9093978!4d80.1968051!16s%2Fg%2F11wfy1hclj?hl=en&entry=ttu&g_ep=EgoyMDI1MDgxMy4wIKXMDSoASAFQAw%3D%3D" target="_blank">
                                    <button
                            class="border border-[#009CFF] text-[#009CFF] px-8 py-2 uppercase text-base font-semibold outline-none focus-none">Get
                            directions</button> </a> 
                    </div>
                </div>

                <div class="px-8">
                    <img src="../assets/divider.png" alt="divider" class="mx-auto mt-4" />
                </div>
            </div>
        </div>
    </section>

    <!--Ashok Nagar location slider  -->
    <section class="max-w-7xl mx-auto pb-8">
        <div
            class="w-[350px] md:w-[1200px] mx-auto flex flex-col md:flex-row space-y-2 justify-center md:space-x-[100px] items-center mt-4 mobile-text-center">
            <div class="w-[200px] md:w-[400px] md:text-right relative">
                <span class=" hidden md:block "><img src="../assets/vector-line-3.png"
                        class="absolute right-[40%] top-[-26%] w-[30px] h-[30px]" alt="vectors"></span>
                <h3 class="text-xl md:text-3xl font-bold font-lora">Ashok Nagar</h3>
                <span class=" hidden md:block "><img src="../assets/vector-right-lines.png"
                        class="absolute right-[-4%] top-[46%] w-[30px] h-[30px" alt="vectors"></span>
            </div>
            <div class="w-[300px] md:w-[600px] text-left">
                <p class="mobile-text-center md:text-left">Rohaan Hotel Ashok Nagar brings together style, comfort, and
                    a prime central location. Recognized as
                    a top business class hotel in Ashoka Nagar, the property is perfect for working professionals,
                    transit guests, and shoppers visiting nearby T. Nagar. With metro connectivity and quick access to
                    major business hubs, it stands out among business hotels in Chennai near metro stations.
                </p>
            </div>
        </div>

    </section>
    <section class="max-w-[1400px] mx-auto base-template">
        <div class="base-template__wrapper wrapper">
            <div class="base-template__content">
                <div class="booking-slider">
                    <!-- Slider Navigation -->
                    <div class="booking-slider__nav slider-nav">
                        <div title="Newest offers" tabindex="0" class="slider-nav__item slider-nav__item_prev">
                            <svg width="16" height="28" viewBox="0 0 16 28" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M14 26L2 14L14 2" stroke="white" stroke-width="4" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>
                        </div>
                        <div title="Oldest offers" tabindex="0" class="slider-nav__item slider-nav__item_next">
                            <svg width="16" height="28" viewBox="0 0 16 28" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M2 26L14 14L2 2" stroke="white" stroke-width="4" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>
                        </div>
                    </div>

                    <!-- Slider Content -->

                    <div class="booking-slider__slider swiper">
                        <div class="booking-slider__wrapper swiper-wrapper">

                            <!-- Slider: Slide 1 -->

                            <div class="booking-slider__slide swiper-slide">
                                <div class="booking-slider__item booking-slider-item">
                                    <!-- <div title="The most popular option" class="booking-slider-item__badge">
                                        Popular
                                    </div> -->

                                    <a title="Luxury Detached Home in Bournemouth" href="/"
                                        class="booking-slider-item__image" onclick="event.preventDefault();">
                                        <img src="../assets/bedroom-rohaan.png" alt="Hotels in Medavakkam" />
                                    </a>

                                    <div class="booking-slider-item__content">
                                        <!-- <div class="booking-slider-item__price">
                                            £3,500<small>/month</small>
                                        </div> -->

                                        <h2 class="booking-slider-item__title">
                                            <a title="Hotels in Medavakkam" href="/" onclick="event.preventDefault();">
                                                Deluxe Double Room
                                            </a>
                                        </h2>

                                        <!-- <div title="Address" class="booking-slider-item__address">
                                            <span class="booking-slider-item__address-icon">
                                                <img src="https://bato-web-agency.github.io/bato-shared/img/slider-2/icon-address.svg"
                                                    alt="Address" />
                                            </span>
                                            29 Terrace Rd, BH2 5EL
                                        </div> -->

                                        <div class="booking-slider-item__text">
                                            Enjoy a refined stay in our Deluxe Double Room with air-conditioned rooms,
                                            featuring an array of amenities designed to ensure maximum comfort and ease
                                            throughout your visit.
                                        </div>

                                        <div class="py-4">
                                            <img src="../assets/black-line.png" alt="black-line-vector" />
                                        </div>

                                        <div class="booking-slider-item__footer">
                                            <div class="booking-slider-item__footer-inner">
                                                <div class="booking-slider-item__amenities grid grid-cols-2">
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/queensizebed.png" alt="queensizebed" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Queen Size 170
                                                            Sq.ft</div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/digitalsafe.png" alt="digitalsafe" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Digital Safe
                                                        </div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/hotwater.png" alt="hotwater" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">24x7 hot water
                                                        </div>
                                                    </div>
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/airconditioner.png"
                                                                alt="airconditioner" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Air conditioner
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="py-4">
                                                    <img src="../assets/black-line.png" alt="black-line-vector" />
                                                </div>
                                                <div class="flex  items-center justify-between">
                                                    <div>
                                                        <a class="booking-slider-item__btn" href="/"
                                                            onclick="event.preventDefault();">
                                                            <span class="booking-slider-item__btn-text">Book Now</span>
                                                            <span class="booking-slider-item__btn-icon"></span>
                                                        </a>
                                                    </div>
                                                    <div>
                                                        <p class="text-[#004875] font-bold text-xl">₹2,500 / Night</p>

                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Slider: Slide 2 -->

                            <div class="booking-slider__slide swiper-slide">
                                <div class="booking-slider__item booking-slider-item">
                                    <!-- <div title="The most popular option" class="booking-slider-item__badge">
                                        Popular
                                    </div> -->

                                    <a title="Luxury Detached Home in Bournemouth" href="/"
                                        class="booking-slider-item__image" onclick="event.preventDefault();">
                                        <img src="../assets/double-bedroom-with-breakfast.png"
                                            alt="Hotels in Medavakkam" />
                                    </a>

                                    <div class="booking-slider-item__content">
                                        <!-- <div class="booking-slider-item__price">
                                            £3,500<small>/month</small>
                                        </div> -->

                                        <h2 class="booking-slider-item__title">
                                            <a title="Hotels in Medavakkam" href="/" onclick="event.preventDefault();">
                                                Deluxe Double Room with breakfast
                                            </a>
                                        </h2>

                                        <!-- <div title="Address" class="booking-slider-item__address">
                                            <span class="booking-slider-item__address-icon">
                                                <img src="https://bato-web-agency.github.io/bato-shared/img/slider-2/icon-address.svg"
                                                    alt="Address" />
                                            </span>
                                            29 Terrace Rd, BH2 5EL
                                        </div> -->

                                        <div class="booking-slider-item__text">
                                            Start your day right in our Deluxe Double room with a delicious breakfast
                                            and an array of amenities thoughtfully designed for your perfect stay.
                                        </div>

                                        <div class="py-4">
                                            <img src="../assets/black-line.png" alt="black-line-vector" />
                                        </div>

                                        <div class="booking-slider-item__footer">
                                            <div class="booking-slider-item__footer-inner">
                                                <div class="booking-slider-item__amenities grid grid-cols-2">
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/queensizebed.png" alt="queensizebed" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Queen Size 170
                                                            Sq.ft</div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/digitalsafe.png" alt="digitalsafe" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Digital Safe
                                                        </div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/hotwater.png" alt="hotwater" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">24x7 hot water
                                                        </div>
                                                    </div>
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/airconditioner.png"
                                                                alt="airconditioner" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Air conditioner
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="py-4">
                                                    <img src="../assets/black-line.png" alt="black-line-vector" />
                                                </div>
                                                <div class="flex  items-center justify-between">
                                                    <div>
                                                        <a class="booking-slider-item__btn" href="/"
                                                            onclick="event.preventDefault();">
                                                            <span class="booking-slider-item__btn-text">Book Now</span>
                                                            <span class="booking-slider-item__btn-icon"></span>
                                                        </a>
                                                    </div>
                                                    <div>
                                                        <p class="text-[#004875] font-bold text-xl">₹2,700 / Night</p>

                                                    </div>
                                                </div>

                                            </div>
                                        </div>



                                    </div>
                                </div>
                            </div>

                            <!-- Slider: Slide 3 -->

                            <div class="booking-slider__slide swiper-slide">
                                <div class="booking-slider__item booking-slider-item">
                                    <!-- <div title="The most popular option" class="booking-slider-item__badge">
                                        Popular
                                    </div> -->

                                    <a title="Luxury Detached Home in Bournemouth" href="/"
                                        class="booking-slider-item__image" onclick="event.preventDefault();">
                                        <img src="../assets/twin-room.png" alt="Hotels in Medavakkam" />
                                    </a>

                                    <div class="booking-slider-item__content">
                                        <!-- <div class="booking-slider-item__price">
                                            £3,500<small>/month</small>
                                        </div> -->

                                        <h2 class="booking-slider-item__title">
                                            <a title="Hotels in Medavakkam" href="/" onclick="event.preventDefault();">
                                                Deluxe Twin Room
                                            </a>
                                        </h2>

                                        <!-- <div title="Address" class="booking-slider-item__address">
                                            <span class="booking-slider-item__address-icon">
                                                <img src="https://bato-web-agency.github.io/bato-shared/img/slider-2/icon-address.svg"
                                                    alt="Address" />
                                            </span>
                                            29 Terrace Rd, BH2 5EL
                                        </div> -->

                                        <div class="booking-slider-item__text">
                                            Enjoy the perfect blend of comfort and convenience in our twin room, with
                                            two comfortable beds and amenities to refresh and revitalise.
                                        </div>

                                        <div class="py-4">
                                            <img src="../assets/black-line.png" alt="black-line-vector" />
                                        </div>

                                        <div class="booking-slider-item__footer">
                                            <div class="booking-slider-item__footer-inner">
                                                <div class="booking-slider-item__amenities grid grid-cols-2">
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/twin-bedroom.png" alt="twin-bedroom" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Twin Beds 150
                                                            Sq.ft</div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/digitalsafe.png" alt="digitalsafe" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Digital Safe
                                                        </div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/hotwater.png" alt="hotwater" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">24x7 hot water
                                                        </div>
                                                    </div>
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/airconditioner.png"
                                                                alt="airconditioner" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Air conditioner
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="py-4">
                                                    <img src="../assets/black-line.png" alt="black-line-vector" />
                                                </div>
                                                <div class="flex  items-center justify-between">
                                                    <div>
                                                        <a class="booking-slider-item__btn" href="/"
                                                            onclick="event.preventDefault();">
                                                            <span class="booking-slider-item__btn-text">Book Now</span>
                                                            <span class="booking-slider-item__btn-icon"></span>
                                                        </a>
                                                    </div>
                                                    <div>
                                                        <p class="text-[#004875] font-bold text-xl">₹2,850/ Night</p>

                                                    </div>
                                                </div>

                                            </div>
                                        </div>



                                    </div>
                                </div>
                            </div>

                            <!-- Slider: Slide 4 -->
                            <div class="booking-slider__slide swiper-slide">
                                <div class="booking-slider__item booking-slider-item">
                                    <!-- <div title="The most popular option" class="booking-slider-item__badge">
                                        Popular
                                    </div> -->

                                    <a title="Luxury Detached Home in Bournemouth" href="/"
                                        class="booking-slider-item__image" onclick="event.preventDefault();">
                                        <img src="../assets/twin-bedroom-with-breakfast.png"
                                            alt="Hotels in Medavakkam" />
                                    </a>

                                    <div class="booking-slider-item__content">
                                        <!-- <div class="booking-slider-item__price">
                                            £3,500<small>/month</small>
                                        </div> -->

                                        <h2 class="booking-slider-item__title">
                                            <a title="Hotels in Medavakkam" href="/" onclick="event.preventDefault();">
                                                Deluxe Twin Room With breakfast
                                            </a>
                                        </h2>

                                        <!-- <div title="Address" class="booking-slider-item__address">
                                            <span class="booking-slider-item__address-icon">
                                                <img src="https://bato-web-agency.github.io/bato-shared/img/slider-2/icon-address.svg"
                                                    alt="Address" />
                                            </span>
                                            29 Terrace Rd, BH2 5EL
                                        </div> -->

                                        <div class="booking-slider-item__text">
                                            Enjoy the perfect blend of comfort and convenience in our twin room, with
                                            two comfortable beds and amenities to refresh and revitalise.
                                        </div>

                                        <div class="py-4">
                                            <img src="../assets/black-line.png" alt="black-line-vector" />
                                        </div>

                                        <div class="booking-slider-item__footer">
                                            <div class="booking-slider-item__footer-inner">
                                                <div class="booking-slider-item__amenities grid grid-cols-2">
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/twin-bedroom.png" alt="queensizebed" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Twin Beds 150
                                                            Sq.ft</div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/digitalsafe.png" alt="digitalsafe" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Digital Safe
                                                        </div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/hotwater.png" alt="hotwater" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">24x7 hot water
                                                        </div>
                                                    </div>
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/airconditioner.png"
                                                                alt="airconditioner" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Air conditioner
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="py-4">
                                                    <img src="../assets/black-line.png" alt="black-line-vector" />
                                                </div>
                                                <div class="flex  items-center justify-between">
                                                    <div>
                                                        <a class="booking-slider-item__btn" href="/"
                                                            onclick="event.preventDefault();">
                                                            <span class="booking-slider-item__btn-text">Book Now</span>
                                                            <span class="booking-slider-item__btn-icon"></span>
                                                        </a>
                                                    </div>
                                                    <div>
                                                        <p class="text-[#004875] font-bold text-xl">₹3,000/ Night</p>

                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <!-- Slider Pagination -->

                    <div class="booking-slider__pagination slider-pagination"></div>
                </div>
                <div class="max-w-6xl px-2 md:px-0  mx-auto text-center mt-8 mb-8">
                    <p>For guests searching for budget hotels in Ashoka Nagar, Rohaan offers premium amenities at
                        competitive rates. Clean rooms, attentive service, and access to popular city landmarks like
                        Ashok Pillar and Udayam Theatre make this hotel a reliable option for both leisure and corporate
                        stays.
                    </p>
                    <div
                        class="max-w-sm mx-auto flex flex-col md:flex-row space-y-5 md:space-y-0 items-center justify-between mt-8">
                        <button
                            class="bg-[#009CFF] text-white px-8 py-2 uppercase text-base font-semibold outline-none animated-button victoria-one">Read
                            more</button>
                             <a href="https://www.google.com/maps/place/Rohaan+Inns+by+UPAR+Hotels+Ashok+Nagar/@13.0361683,80.2124265,17z/data=!4m9!3m8!1s0x3a526724905210bd:0x69bb5095803bc911!5m2!4m1!1i2!8m2!3d13.0361683!4d80.2150014!16s%2Fg%2F11r7621m9s?entry=ttu&g_ep=EgoyMDI1MDgxMy4wIKXMDSoASAFQAw%3D%3D" target="_blank">
                                    <button
                            class="border border-[#009CFF] text-[#009CFF] px-8 py-2 uppercase text-base font-semibold outline-none">Get
                            directions</button> </a> 
                        <!-- <button
                            class="border border-[#009CFF] text-[#009CFF] px-8 py-2 uppercase text-base font-semibold outline-none">Get
                            directions</button> -->
                    </div>
                </div>

                <div class="px-8">
                    <img src="../assets/divider.png" alt="divider" class="mx-auto mt-8 mb-8" />
                </div>
            </div>
        </div>
    </section>

    <!--Perumbakkam location slider  -->
    <section class="max-w-7xl mx-auto pb-8">
        <div
            class="w-[350px] md:w-[1200px] mx-auto flex flex-col md:flex-row space-y-2 justify-center md:space-x-[100px] items-center mt-4 mobile-text-center">
            <div class="w-[200px] md:w-[400px] md:text-right relative">
                <span class=" hidden md:block "><img src="../assets/vector-line-3.png"
                        class="absolute right-[46%] top-[-26%] w-[30px] h-[30px]" alt="vectors"></span>
                <h3 class="text-xl md:text-3xl font-bold font-lora">Perumbakkam</h3>
                <p class="mobile-text-center md:text-right w-[150px] md:w-[300px] mx-auto">(Business Suite)</p>
                <span class=" hidden md:block "><img src="../assets/vector-right-lines.png"
                        class="absolute right-[-4%] top-[46%] w-[30px] h-[30px" alt="vectors"></span>
            </div>

            <div class="w-[300px] md:w-[600px] text-left">
                <p class="mobile-text-center md:text-left">Rohaan Hotels in Perumbakkam is a quiet and professionally
                    managed stay option located near key IT
                    parks, hospitals, and residential neighborhoods. If you're searching for a business class hotel in
                    Perumbakkam or a convenient stay near Sholinganallur or Medavakkam, this hotel offers the right mix
                    of affordability and quality.
                </p>
            </div>
        </div>
    </section>
    <section class="max-w-[1400px] mx-auto base-template">
        <div class="base-template__wrapper wrapper">
            <div class="base-template__content">
                <div class="booking-slider">
                    <!-- Slider Navigation -->
                    <div class="booking-slider__nav slider-nav">
                        <div title="Newest offers" tabindex="0" class="slider-nav__item slider-nav__item_prev">
                            <svg width="16" height="28" viewBox="0 0 16 28" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M14 26L2 14L14 2" stroke="white" stroke-width="4" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>
                        </div>
                        <div title="Oldest offers" tabindex="0" class="slider-nav__item slider-nav__item_next">
                            <svg width="16" height="28" viewBox="0 0 16 28" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M2 26L14 14L2 2" stroke="white" stroke-width="4" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>
                        </div>
                    </div>

                    <!-- Slider Content -->

                    <div class="booking-slider__slider swiper">
                        <div class="booking-slider__wrapper swiper-wrapper">

                            <!-- Slider: Slide 1 -->

                            <div class="booking-slider__slide swiper-slide">
                                <div class="booking-slider__item booking-slider-item">
                                    <!-- <div title="The most popular option" class="booking-slider-item__badge">
                                        Popular
                                    </div> -->

                                    <a title="Luxury Detached Home in Bournemouth" href="/"
                                        class="booking-slider-item__image" onclick="event.preventDefault();">
                                        <img src="../assets/bedroom-rohaan.png" alt="Hotels in Medavakkam" />
                                    </a>

                                    <div class="booking-slider-item__content">
                                        <!-- <div class="booking-slider-item__price">
                                            £3,500<small>/month</small>
                                        </div> -->

                                        <h2 class="booking-slider-item__title">
                                            <a title="Hotels in Medavakkam" href="/" onclick="event.preventDefault();">
                                                Deluxe Double Room
                                            </a>
                                        </h2>

                                        <!-- <div title="Address" class="booking-slider-item__address">
                                            <span class="booking-slider-item__address-icon">
                                                <img src="https://bato-web-agency.github.io/bato-shared/img/slider-2/icon-address.svg"
                                                    alt="Address" />
                                            </span>
                                            29 Terrace Rd, BH2 5EL
                                        </div> -->

                                        <div class="booking-slider-item__text">
                                            Enjoy a refined stay in our Deluxe Double Room with air-conditioned rooms,
                                            featuring an array of amenities designed to ensure maximum comfort and ease
                                            throughout your visit.
                                        </div>

                                        <div class="py-4">
                                            <img src="../assets/black-line.png" alt="black-line-vector" />
                                        </div>

                                        <div class="booking-slider-item__footer">
                                            <div class="booking-slider-item__footer-inner">
                                                <div class="booking-slider-item__amenities grid grid-cols-2">
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/queensizebed.png" alt="queensizebed" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Queen Size 170
                                                            Sq.ft</div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/digitalsafe.png" alt="digitalsafe" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Digital Safe
                                                        </div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/hotwater.png" alt="hotwater" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">24x7 hot water
                                                        </div>
                                                    </div>
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/airconditioner.png"
                                                                alt="airconditioner" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Air conditioner
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="py-4">
                                                    <img src="../assets/black-line.png" alt="black-line-vector" />
                                                </div>
                                                <div class="flex  items-center justify-between">
                                                    <div>
                                                        <a class="booking-slider-item__btn" href="/"
                                                            onclick="event.preventDefault();">
                                                            <span class="booking-slider-item__btn-text">Book Now</span>
                                                            <span class="booking-slider-item__btn-icon"></span>
                                                        </a>
                                                    </div>
                                                    <div>
                                                        <p class="text-[#004875] font-bold text-xl">₹2,500 / Night</p>

                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Slider: Slide 2 -->

                            <div class="booking-slider__slide swiper-slide">
                                <div class="booking-slider__item booking-slider-item">
                                    <!-- <div title="The most popular option" class="booking-slider-item__badge">
                                        Popular
                                    </div> -->

                                    <a title="Luxury Detached Home in Bournemouth" href="/"
                                        class="booking-slider-item__image" onclick="event.preventDefault();">
                                        <img src="../assets/double-bedroom-with-breakfast.png"
                                            alt="Hotels in Medavakkam" />
                                    </a>

                                    <div class="booking-slider-item__content">
                                        <!-- <div class="booking-slider-item__price">
                                            £3,500<small>/month</small>
                                        </div> -->

                                        <h2 class="booking-slider-item__title">
                                            <a title="Hotels in Medavakkam" href="/" onclick="event.preventDefault();">
                                                Deluxe Double Room with breakfast
                                            </a>
                                        </h2>

                                        <!-- <div title="Address" class="booking-slider-item__address">
                                            <span class="booking-slider-item__address-icon">
                                                <img src="https://bato-web-agency.github.io/bato-shared/img/slider-2/icon-address.svg"
                                                    alt="Address" />
                                            </span>
                                            29 Terrace Rd, BH2 5EL
                                        </div> -->

                                        <div class="booking-slider-item__text">
                                            Start your day right in our Deluxe Double room with a delicious breakfast
                                            and an array of amenities thoughtfully designed for your perfect stay.
                                        </div>

                                        <div class="py-4">
                                            <img src="../assets/black-line.png" alt="black-line-vector" />
                                        </div>

                                        <div class="booking-slider-item__footer">
                                            <div class="booking-slider-item__footer-inner">
                                                <div class="booking-slider-item__amenities grid grid-cols-2">
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/queensizebed.png" alt="queensizebed" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Queen Size 170
                                                            Sq.ft</div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/digitalsafe.png" alt="digitalsafe" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Digital Safe
                                                        </div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/hotwater.png" alt="hotwater" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">24x7 hot water
                                                        </div>
                                                    </div>
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/airconditioner.png"
                                                                alt="airconditioner" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Air conditioner
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="py-4">
                                                    <img src="../assets/black-line.png" alt="black-line-vector" />
                                                </div>
                                                <div class="flex  items-center justify-between">
                                                    <div>
                                                        <a class="booking-slider-item__btn" href="/"
                                                            onclick="event.preventDefault();">
                                                            <span class="booking-slider-item__btn-text">Book Now</span>
                                                            <span class="booking-slider-item__btn-icon"></span>
                                                        </a>
                                                    </div>
                                                    <div>
                                                        <p class="text-[#004875] font-bold text-xl">₹2,700 / Night</p>

                                                    </div>
                                                </div>

                                            </div>
                                        </div>



                                    </div>
                                </div>
                            </div>

                            <!-- Slider: Slide 3 -->

                            <div class="booking-slider__slide swiper-slide">
                                <div class="booking-slider__item booking-slider-item">
                                    <!-- <div title="The most popular option" class="booking-slider-item__badge">
                                        Popular
                                    </div> -->

                                    <a title="Luxury Detached Home in Bournemouth" href="/"
                                        class="booking-slider-item__image" onclick="event.preventDefault();">
                                        <img src="../assets/twin-room.png" alt="Hotels in Medavakkam" />
                                    </a>

                                    <div class="booking-slider-item__content">
                                        <!-- <div class="booking-slider-item__price">
                                            £3,500<small>/month</small>
                                        </div> -->

                                        <h2 class="booking-slider-item__title">
                                            <a title="Hotels in Medavakkam" href="/" onclick="event.preventDefault();">
                                                Deluxe Twin Room
                                            </a>
                                        </h2>

                                        <!-- <div title="Address" class="booking-slider-item__address">
                                            <span class="booking-slider-item__address-icon">
                                                <img src="https://bato-web-agency.github.io/bato-shared/img/slider-2/icon-address.svg"
                                                    alt="Address" />
                                            </span>
                                            29 Terrace Rd, BH2 5EL
                                        </div> -->

                                        <div class="booking-slider-item__text">
                                            Enjoy the perfect blend of comfort and convenience in our twin room, with
                                            two comfortable beds and amenities to refresh and revitalise.
                                        </div>

                                        <div class="py-4">
                                            <img src="../assets/black-line.png" alt="black-line-vector" />
                                        </div>

                                        <div class="booking-slider-item__footer">
                                            <div class="booking-slider-item__footer-inner">
                                                <div class="booking-slider-item__amenities grid grid-cols-2">
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/twin-bedroom.png" alt="twin-bedroom" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Twin Beds 150
                                                            Sq.ft</div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/digitalsafe.png" alt="digitalsafe" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Digital Safe
                                                        </div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/hotwater.png" alt="hotwater" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">24x7 hot water
                                                        </div>
                                                    </div>
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/airconditioner.png"
                                                                alt="airconditioner" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Air conditioner
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="py-4">
                                                    <img src="../assets/black-line.png" alt="black-line-vector" />
                                                </div>
                                                <div class="flex  items-center justify-between">
                                                    <div>
                                                        <a class="booking-slider-item__btn" href="/"
                                                            onclick="event.preventDefault();">
                                                            <span class="booking-slider-item__btn-text">Book Now</span>
                                                            <span class="booking-slider-item__btn-icon"></span>
                                                        </a>
                                                    </div>
                                                    <div>
                                                        <p class="text-[#004875] font-bold text-xl">₹2,850/ Night</p>

                                                    </div>
                                                </div>

                                            </div>
                                        </div>



                                    </div>
                                </div>
                            </div>

                            <!-- Slider: Slide 4 -->
                            <div class="booking-slider__slide swiper-slide">
                                <div class="booking-slider__item booking-slider-item">
                                    <!-- <div title="The most popular option" class="booking-slider-item__badge">
                                        Popular
                                    </div> -->

                                    <a title="Luxury Detached Home in Bournemouth" href="/"
                                        class="booking-slider-item__image" onclick="event.preventDefault();">
                                        <img src="../assets/twin-bedroom-with-breakfast.png"
                                            alt="Hotels in Medavakkam" />
                                    </a>

                                    <div class="booking-slider-item__content">
                                        <!-- <div class="booking-slider-item__price">
                                            £3,500<small>/month</small>
                                        </div> -->

                                        <h2 class="booking-slider-item__title">
                                            <a title="Hotels in Medavakkam" href="/" onclick="event.preventDefault();">
                                                Deluxe Twin Room With breakfast
                                            </a>
                                        </h2>

                                        <!-- <div title="Address" class="booking-slider-item__address">
                                            <span class="booking-slider-item__address-icon">
                                                <img src="https://bato-web-agency.github.io/bato-shared/img/slider-2/icon-address.svg"
                                                    alt="Address" />
                                            </span>
                                            29 Terrace Rd, BH2 5EL
                                        </div> -->

                                        <div class="booking-slider-item__text">
                                            Enjoy the perfect blend of comfort and convenience in our twin room, with
                                            two comfortable beds and amenities to refresh and revitalise.
                                        </div>

                                        <div class="py-4">
                                            <img src="../assets/black-line.png" alt="black-line-vector" />
                                        </div>

                                        <div class="booking-slider-item__footer">
                                            <div class="booking-slider-item__footer-inner">
                                                <div class="booking-slider-item__amenities grid grid-cols-2">
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/twin-bedroom.png" alt="queensizebed" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Twin Beds 150
                                                            Sq.ft</div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/digitalsafe.png" alt="digitalsafe" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Digital Safe
                                                        </div>
                                                    </div>

                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/hotwater.png" alt="hotwater" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">24x7 hot water
                                                        </div>
                                                    </div>
                                                    <div class="booking-slider-item__amenity">
                                                        <div class="booking-slider-item__amenity-icon">
                                                            <img src="../assets/airconditioner.png"
                                                                alt="airconditioner" />
                                                        </div>
                                                        <div class="booking-slider-item__amenity-text">Air conditioner
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="py-4">
                                                    <img src="../assets/black-line.png" alt="black-line-vector" />
                                                </div>
                                                <div class="flex  items-center justify-between">
                                                    <div>
                                                        <a class="booking-slider-item__btn" href="/"
                                                            onclick="event.preventDefault();">
                                                            <span class="booking-slider-item__btn-text">Book Now</span>
                                                            <span class="booking-slider-item__btn-icon"></span>
                                                        </a>
                                                    </div>
                                                    <div>
                                                        <p class="text-[#004875] font-bold text-xl">₹3,000/ Night</p>

                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <!-- Slider Pagination -->

                    <div class="booking-slider__pagination slider-pagination"></div>
                </div>
                <div class="max-w-6xl px-2 md:px-0  mx-auto text-center mt-8 mb-8">
                    <p>Rohaan Hotels is frequently chosen by guests looking for budget hotels in Perumbakkam, especially
                        those visiting Global Hospital, Elcot SEZ, or OMR. With well appointed rooms, excellent service,
                        and a calm atmosphere, it’s one of the most dependable budget hotels in Chennai for both
                        business and personal travel.</p>
                    <div
                        class="max-w-sm mx-auto flex flex-col md:flex-row space-y-5 md:space-y-0 items-center justify-between mt-8 ">
                        <button
                            class="bg-[#009CFF] text-white px-8 py-2 uppercase text-base font-semibold outline-none animated-button victoria-one">Read
                            more</button>
                               <a href="https://www.google.com/maps/place/Rohaan+Hotels+Medavakkam+by+UPAR/@12.9093978,80.1942302,17z/data=!4m9!3m8!1s0x3a525dddafbf6983:0x313f72403e08ee91!5m2!4m1!1i2!8m2!3d12.9093978!4d80.1968051!16s%2Fg%2F11wfy1hclj?hl=en&entry=ttu&g_ep=EgoyMDI1MDgxMy4wIKXMDSoASAFQAw%3D%3D" target="_blank">
                                    <button
                            class="border border-[#009CFF] text-[#009CFF] px-8 py-2 uppercase text-base font-semibold outline-none focus-none">Get
                            directions</button> </a> 
                        <!-- <button
                            class="border border-[#009CFF] text-[#009CFF] px-8 py-2 uppercase text-base font-semibold outline-none">Get
                            directions</button> -->
                    </div>
                </div>

                <div class="px-8">
                    <img src="../assets/divider.png" alt="divider" class="mx-auto mt-4 mb-4" />
                </div>
            </div>
        </div>
    </section>



    <!-- why choose us section  -->
    <section class="w-full max-w-[1600px] bg-[url('../assets/why-choose-bg.png')] bg-cover bg-center mx-auto p-8">
        <h3 class="font-lora text-xl md:text-3xl text-center text-[#004875]">Why Choose Rohaan Hotels for Business Class
            Hotels in
            Chennai?</h3>
        <div
            class="flex justify-center max-w-5xl mx-auto mt-8 flex-col space-y-4 md:space-y-0 md:flex-row items-center">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4 max-w-4xl mx-auto">
                <div
                    class="bg-[#E3E3E3] bg-[url('../assets/bg1.png')]   w-80 p-4 rounded-md flex flex-col p-6 items-center md:items-start">
                    <img src="../assets/setting.png" class="w-8 h-8 mb-2" alt="icon">
                    <p class="mobile-text-center md:text-start">Elegant, spacious rooms in every business class hotel in
                        Chennai</p>
                </div>
                <div
                    class="bg-[#E3E3E3] bg-[url('../assets/bg2.png')]  w-80 p-4 rounded-md flex flex-col p-6 items-center md:items-start">
                    <img src="../assets/hand-icon.png" class="w-8 h-8 mb-2" alt="icon">
                    <p class="mobile-text-center md:text-start">Trusted name among budget hotels in Ashoka Nagar and
                        Medavakkam</p>
                </div>
                <div
                    class="bg-[#E3E3E3] bg-[url('../assets/bg3.png')]  w-80 p-4 rounded-md flex flex-col p-6 items-center md:items-start">
                    <img src="../assets/time-icon.png" class="w-8 h-8 mb-2" alt="icon">
                    <p class="mobile-text-center md:text-start">24/7 front desk, concierge, and support services</p>
                </div>
                <div
                    class="bg-[#E3E3E3] bg-[url('../assets/bg4.png')]  w-80 p-4 rounded-md flex flex-col p-6 items-center md:items-start">
                    <img src="../assets/map.png" class="w-8 h-8 mb-2" alt="icon">
                    <p class="mobile-text-center md:text-start">Easy access to restaurants, malls, and city transport
                    </p>
                </div>
            </div>
            <div
                class="bg-[#E3E3E3] bg-[url('../assets/bg5.png')] w-80 p-4 rounded-md flex flex-col p-6  h-[165px] md:h-[280px] md:mt-0 items-center md:items-start">
                <img src="../assets/badge.png" class="w-8 h-8 mb-2" alt="icon">
                <p class="mobile-text-center md:text-start">Excellent locations near IT corridors like OMR,
                    Sholinganallur & Perumbakkam</p>
            </div>
        </div>
        <p class="text-center text-base mt-8 italic">“Whether you're a business traveler or a tourist, Rohaan Hotels is
            your go-to option for both business class and budget hotels in Chennai.”</p>
    </section>

    <!-- Amenities  -->
    <section class="max-w-[1550px] mx-auto mb-8 pt-8 relative bg-[url(../assets/medavakkam-bg-1.png)] bg-cover">
        <!-- <img src="../assets/medavakkam-bg-1.png" class="absolute top-0 right-0 w-[500px] h-[600px] object-contain" alt="medavakkam-bg-1">v   -->
        <div class="flex items-center justify-center max-w-sm md:max-w-2xl mx-auto ">
            <span><img src="../assets/line1.png" alt="line-vector"></span>
            <h2 class="px-4 font-lora text-2xl  md:text-3xl text-center text-[#004875]">Amenities</h2>
            <span><img src="../assets/Line2.png" alt="line-vector"></span>
        </div>
        <h4 class="text-center text-xl mt-5">General Amenities</h4>
        <div class="grid grid-cols-1 md:grid-cols-3 max-w-sm   md:max-w-6xl gap-4 mt-8  mx-auto">
            <div class="w-80 md:max-w-2xl mx-auto p-4 relative">
                <div class="border border-[#009CFF] max-w-72 p-2">
                    <img src="../assets/receptionist.png" class="w-[300px]" alt="24-hour reception & concierge">
                </div>
                <div class="bg-[#009CFF] text-white px-2 py-2 w-[200px] absolute bottom-0 animated-button victoria-one">
                    <button class="border border-[white] p-2 text-sm"> 24-hour reception & concierge</button>
                </div>
            </div>
            <div class="w-80 md:max-w-2xl mx-auto p-4 relative">
                <div class="border border-[#009CFF] max-w-72 p-2">
                    <img src="../assets/wifi.png" class="w-[300px]" alt="Free Wi-Fi throughout the property">
                </div>
                <div
                    class="bg-[#009CFF] text-white px-2 py-2  w-[200px] absolute bottom-0 animated-button victoria-one">
                    <button class="border border-[white] p-2 text-sm "> Free Wi-Fi throughout the property</button>
                </div>
            </div>
            <div class="w-80 md:max-w-2xl mx-auto p-4 relative">
                <div class="border border-[#009CFF] max-w-72 p-2">
                    <img src="../assets/parking.png" class="w-[300px]" alt="Paid public parking">
                </div>
                <div
                    class="bg-[#009CFF] text-white px-2 py-2  w-[200px] absolute bottom-0 animated-button victoria-one">
                    <button class="border border-[white] p-3 text-sm text-center w-[185px]"> Paid public
                        parking</button>
                </div>
            </div>
        </div>
        <div class="grid  grid-cols-1 md:grid-cols-2 gap-4 mt-8 max-w-sm md:max-w-3xl mx-auto">
            <div class="w-80 md:max-w-2xl mx-auto p-4 relative">
                <div class="border border-[#009CFF] max-w-72 p-2">
                    <img src="../assets/ac-rooms.png" class="w-[300px]" alt="Air-conditioned rooms & public areas">
                </div>
                <div class="bg-[#009CFF] text-white px-2 py-2 w-[200px] absolute bottom-0 animated-button victoria-one">
                    <button class="border border-[white] p-2 text-sm"> Air-conditioned rooms & public areas</button>
                </div>
            </div>
            <div class="w-80 md:max-w-2xl mx-auto p-4 relative">
                <div class="border border-[#009CFF] max-w-72 p-2">
                    <img src="../assets/luggage.png" class="w-[300px]" alt="Hassle-free luggage support">
                </div>
                <div
                    class="bg-[#009CFF] text-white px-2 py-2  w-[200px] absolute bottom-0 animated-button victoria-one">
                    <button class="border border-[white] p-2 text-sm"> Hassle-free luggage support</button>
                </div>
            </div>

        </div>
    </section>

    <!-- Room Comforts -->
    <section class="max-w-[1550px] mx-auto mb-8 mt-8 md:bg-[url(../assets/roomcomforts-bg.png)] bg-cover">
        <h4 class="text-center text-2xl mt-5">Room Comforts</h4>
        <div class="grid grid-cols-1 md:grid-cols-3 max-w-sm   md:max-w-6xl gap-4 mt-8  mx-auto">
            <div class="w-80 md:max-w-2xl mx-auto p-4 relative">
                <div class="border border-[#009CFF] max-w-72 p-2">
                    <img src="../assets/tv.png" class="w-[300px]" alt="Flat-screen TV with satellite channels">
                </div>
                <div class="bg-[#009CFF] text-white px-2 py-2 w-[200px] absolute bottom-0 animated-button victoria-one">
                    <button class="border border-[white] p-2 text-sm"> Flat-screen TV with satellite channels</button>
                </div>
            </div>
            <div class="w-80 md:max-w-2xl mx-auto p-4 relative">
                <div class="border border-[#009CFF] max-w-72 p-2">
                    <img src="../assets/complementery.png" class="w-[300px]" alt="Complimentary toiletries">
                </div>
                <div
                    class="bg-[#009CFF] text-white px-2 py-2  w-[200px] absolute bottom-0 animated-button victoria-one">
                    <button class="border border-[white] px-2 py-1  w-[200px]text-sm"> Complimentary toiletries</button>
                </div>
            </div>
            <div class="w-80 md:max-w-2xl mx-auto p-4 relative">
                <div class="border border-[#009CFF] max-w-72 p-2">
                    <img src="../assets/facilitieshotel.png" class="w-[300px]"
                        alt="Geyser, hairdryer, and ironing facilities">
                </div>
                <div
                    class="bg-[#009CFF] text-white px-2 py-2  w-[200px] absolute bottom-0 animated-button victoria-one">
                    <button class="border border-[white] p-2 text-sm text-center w-[185px] "> Geyser, hairdryer, and
                        ironing facilities</button>
                </div>
            </div>
        </div>
        <div class="grid  grid-cols-1 md:grid-cols-2 gap-4 mt-8 max-w-sm md:max-w-3xl mx-auto">
            <div class="w-80 md:max-w-2xl mx-auto p-4 relative">
                <div class="border border-[#009CFF] max-w-72 p-2">
                    <img src="../assets/wakeupservice.png" class="w-[300px]" alt="Wake-up call service">
                </div>
                <div class="bg-[#009CFF] text-white px-2 py-2 w-[200px] absolute bottom-0 animated-button victoria-one">
                    <button class="border border-[white] p-3 text-sm text-center w-[185px]"> Wake-up call
                        service</button>
                </div>
            </div>
            <div class="w-80 md:max-w-2xl mx-auto p-4 relative">
                <div class="border border-[#009CFF] max-w-72 p-2">
                    <img src="../assets/soundproof.png" class="w-[300px]" alt="Soundproof windows">
                </div>
                <div
                    class="bg-[#009CFF] text-white px-2 py-2  w-[200px] absolute bottom-0 animated-button victoria-one">
                    <button class="border border-[white] p-3 text-sm text-center w-[185px]">Soundproof windows</button>
                </div>
            </div>
        </div>
    </section>

    <!-- Safety & Security-->
    <section class="max-w-[1550px] mx-auto mb-8 mt-8 bg-[url(../assets/safety-security-bg.png)] bg-cover">
        <h4 class="text-center text-2xl mt-5">Safety & Security</h4>
        <div class="grid grid-cols-1 md:grid-cols-3 max-w-sm   md:max-w-6xl gap-4 mt-8  mx-auto">
            <div class="w-80 md:max-w-2xl mx-auto p-4 relative">
                <div class="border border-[#009CFF] max-w-72 p-2">
                    <img src="../assets/cctv.png" class="w-[300px]" alt="24/7 CCTV surveillance">
                </div>
                <div class="bg-[#009CFF] text-white px-2 py-2 w-[200px] absolute bottom-0 animated-button victoria-one">
                    <button class="border border-[white] p-3 text-sm text-center w-[185px]">24/7 CCTV
                        surveillance</button>
                </div>
            </div>
            <div class="w-80 md:max-w-2xl mx-auto p-4 relative">
                <div class="border border-[#009CFF] max-w-72 p-2">
                    <img src="../assets/smoke.png" class="w-[300px]" alt="Smoke detectors & fire extinguishers">
                </div>
                <div
                    class="bg-[#009CFF] text-white px-2 py-2  w-[200px] absolute bottom-0 animated-button victoria-one">
                    <button class="border border-[white] px-2 py-1  w-[200px]text-sm"> Smoke detectors & fire
                        extinguishers</button>
                </div>
            </div>
            <div class="w-80 md:max-w-2xl mx-auto p-4 relative">
                <div class="border border-[#009CFF] max-w-72 p-2">
                    <img src="../assets/first-aid.png" class="w-[300px]" alt="First-aid services on call">
                </div>
                <div
                    class="bg-[#009CFF] text-white px-2 py-2  w-[200px] absolute bottom-0 animated-button victoria-one">
                    <button class="border border-[white] p-3 text-sm text-center w-[185px]">First-aid services on
                        call</button>
                </div>
            </div>
        </div>
    </section>

    <!-- gallery section  -->
    <section id="rooms" class="bg-[#F8F8F8] bg-[url('../assets/gallery-bg.png')]  w-full  mx-auto mt-8">
        <div class="container max-w-xl md:max-w-6xl mx-auto py-8">
            <h3 class="font-lora text-2xl text-[#004875]">Gallery</h3>
            <div class="row space-y-4 md:space-y-0">
                <a href="../assets/bedroom-view.png" data-toggle="lightbox" data-gallery="gallery" class="col-md-4">
                    <img src="../assets/bedroom-view.png" class="img-fluid rounded">
                </a>
                <a href="../assets/bedroom-view-2.png" data-toggle="lightbox" data-gallery="gallery" class="col-md-4">
                    <img src="../assets/bedroom-view-2.png" class="img-fluid rounded">
                </a>
                <a href="../assets/restroom.png" data-toggle="lightbox" data-gallery="gallery" class="col-md-4">
                    <img src="../assets/restroom.png" class="img-fluid rounded">
                </a>
            </div>
            <div class="row space-y-4 md:space-y-0">
                <a href="../assets/lift-view.png" data-toggle="lightbox" data-gallery="gallery" class="col-md-4">
                    <img src="../assets/lift-view.png" class="img-fluid rounded">
                </a>
                <a href="../assets/bedroom-view-3.png" data-toggle="lightbox" data-gallery="gallery" class="col-md-4">
                    <img src="../assets/bedroom-view-3.png" class="img-fluid rounded">
                </a>
                <a href="../assets/parking-hotel.png" data-toggle="lightbox" data-gallery="gallery" class="col-md-4">
                    <img src="../assets/parking-hotel.png" class="img-fluid rounded">
                </a>
            </div>
        </div>
    </section>



    <!-- Contact us starts -->
    <section
        class="contact-us grid grid-cols-1 md:grid-cols-2 gap-[50px] md:gap-[100px] max-w-xl md:max-w-6xl mx-auto  py-8 md:mx-8 md:my-8"
        id="contactus">
        <div class="contact-us-form title  p-4  md:p-8 rounded-2xl" id="contactform">
            <!-- <div class="contact-us-form title  bg-gradient-to-r from-cyan-700 to-cyan-400  p-8 rounded-2xl" id="contactform"> -->

            <h4 class="text-white text-2xl font-bold">Contact Us</h4>
            <?php
            if (isset($_GET['msg']) && $_GET['msg'] == 'success') {
                echo '<p class="success-msg">Thank you for contacting us! We will get back to you soon.</p>';
            } elseif (isset($_GET['msg']) && $_GET['msg'] == 'failed') {
                echo '<p class="error-msg">There was an error submitting your form. Please try again.</p>';
            }
            ?>
            <form method="post" action="action.php" class="flex flex-col gap-2 mt-0">
                <input type="hidden" name="source" value="index">
                <!-- Name -->
                <div class="flex flex-col form__group field">
                    <input type="text" class="form__field" placeholder="Enter Your Name" name="name" id="nameform2"
                        required />
                    <label for="name" class="form__label">Name</label>
                </div>

                <!-- Email -->
                <div class="flex flex-col form__group field">
                    <input type="email" class="form__field" placeholder="Enter Your Email" name="email" id="emailform2"
                        required />
                    <label for="email" class="form__label">Email</label>
                </div>

                <!-- Phone Number -->
                <div class="flex flex-col form__group field">
                    <input type="tel" class="form__field" placeholder="Enter Your Phone Number" name="phone"
                        id="phoneform2" required />
                    <label for="phone" class="form__label">Phone Number</label>
                </div>

                <!-- Location (Dropdown) -->
                <div class="flex flex-col form__group field">
                    <select class="form__field" name="location" id="locationform2" required>
                        <option value="" disabled selected hidden class="text-black text-[12px]">Select Your Location
                        </option>
                        <option value="chennai" class="text-blue-500 text-base">Medavakkam</option>
                        <option value="bangalore " class="text-blue-500 text-base">Perumbakkam</option>
                        <option value="hyderabad" class="text-blue-500 text-base">Ashok Nagar</option>
                    </select>
                </div>

                <input type="submit" value="Submit "
                    class="contact-submit bg-white text-black font-semibold mt-3 px-4 py-2 rounded hover:bg-gray-200 transition-all" />
            </form>
        </div>
        <!-- <div class="map">
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1759.6599278830145!2d80.19516513598836!3d12.909326063907132!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a525dddafbf6983%3A0x313f72403e08ee91!2sRohaan%20Hotels%20Medavakkam%20by%20UPAR!5e1!3m2!1sen!2sin!4v1753774756101!5m2!1sen!2sin"
                width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"></iframe>

        </div> -->

        <div class="content mx-auto ">
            <!-- Content title -->
            <div class="flex justify-center md:justify-start  items-center">
                <img src="../assets/location-icon.png" class="w-[20px] h-[20px] mt-[6px] md:mt-0" alt="map-icon">
                <h2 class="content__title text-2xl text-left underline"> Locations</h2>
            </div>

            <!-- Content inner -->
            <div class="content__inner shadow-none">
                <!-- Tabs -->
                <div class="tabs">
                    <!-- Tabs navigation -->
                    <div class="tabs__nav w-[350px] md:w-[400px] mx-auto">
                        <ul class="tabs__nav-list items-center ">
                            <li class="tabs__nav-item js-active ">Medavakkam</li>
                            <img src="../assets/Line 146.png" class="h-[25px]" alt="line vector">
                            <li class="tabs__nav-item">Perumbakkam</li>
                            <img src="../assets/Line 146.png" class="h-[25px]" alt="line vector">
                            <li class="tabs__nav-item">Ashok Nagar</li>
                        </ul>
                    </div>

                    <!-- Tabs panels -->
                    <div class="tabs__panels">
                        <!-- Panel 1 -->
                        <div class="tabs__panel">
                            <div class="tabs__panel-card">
                                <a
                                    href="https://www.google.com/maps/place/Rohaan+Hotels+Medavakkam+by+UPAR/@12.9093978,80.1942302,17z/data=!4m9!3m8!1s0x3a525dddafbf6983:0x313f72403e08ee91!5m2!4m1!1i2!8m2!3d12.9093978!4d80.1968051!16s%2Fg%2F11wfy1hclj?hl=en&entry=ttu&g_ep=EgoyMDI1MDgxMy4wIKXMDSoASAFQAw%3D%3D">
                                    <iframe
                                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.9739188469334!2d80.19680509999999!3d12.9093978!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a525dddafbf6983%3A0x313f72403e08ee91!2sRohaan%20Hotels%20Medavakkam%20by%20UPAR!5e0!3m2!1sen!2sin!4v1753792343975!5m2!1sen!2sin"
                                        style="border:0;" allowfullscreen="" loading="lazy"
                                        referrerpolicy="no-referrer-when-downgrade"
                                        class="w-[350px] h-[350px] md:w-[600px] md:h-[350px]"></iframe>
                                </a>
                            </div>
                        </div>

                        <div class="tabs__panel">
                            <div class="tabs__panel-card">
                                <a
                                    href="https://www.google.com/maps/place/Rohaan+Hotels+Medavakkam+by+UPAR/@12.9093978,80.1942302,17z/data=!4m9!3m8!1s0x3a525dddafbf6983:0x313f72403e08ee91!5m2!4m1!1i2!8m2!3d12.9093978!4d80.1968051!16s%2Fg%2F11wfy1hclj?hl=en&entry=ttu&g_ep=EgoyMDI1MDgxMy4wIKXMDSoASAFQAw%3D%3D">
                                    <iframe
                                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.9739188469334!2d80.19680509999999!3d12.9093978!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a525dddafbf6983%3A0x313f72403e08ee91!2sRohaan%20Hotels%20Medavakkam%20by%20UPAR!5e0!3m2!1sen!2sin!4v1753792343975!5m2!1sen!2sin"
                                        style="border:0;" allowfullscreen="" loading="lazy"
                                        referrerpolicy="no-referrer-when-downgrade"
                                        class="w-[350px] h-[350px] md:w-[600px] md:h-[350px]"></iframe>
                                </a>
                            </div>

                        </div>

                        <div class="tabs__panel">
                            <div class="tabs__panel-card">
                                <iframe
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3886.9922000229753!2d80.21242647484252!3d13.036168287285246!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a526724905210bd%3A0x69bb5095803bc911!2sRohaan%20Inns%20by%20UPAR%20Hotels%20Ashok%20Nagar!5e0!3m2!1sen!2sin!4v1753793605353!5m2!1sen!2sin"
                                    style="border:0;" allowfullscreen="" loading="lazy"
                                    referrerpolicy="no-referrer-when-downgrade"
                                    class="w-[350px] h-[350px] md:w-[600px] md:h-[350px]"></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact us ends -->

    <!-- banner section  -->
    <section class="max-w-[1550px] mx-auto">
        <img class="w-full mx-auto" src="../assets/hotel-banner.jpg" alt="rohaan hotels">
    </section>

    <?php include("inc/footer.php") ?>

</body>

</html>