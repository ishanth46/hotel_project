<?php
/*##########Script Information#########
  # Purpose: Send mail Using PHPMailer#
  #          & Gmail SMTP Server 	  #
  # Created: 24-11-2019 			  #
  #	Author : Hafiz Haider			  #
  # Version: 1.0					  #
  # Website: www.BroExperts.com 	  #
  #####################################*/

//Include required PHPMailer files
	require 'includes/PHPMailer.php';
	require 'includes/SMTP.php';
	require 'includes/Exception.php';
//Define name spaces
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\SMTP;
	use PHPMailer\PHPMailer\Exception;

function shoot_mailer($to,$cc,$bcc,$subject,$message,$file){

//Create instance of PHPMailer
	$mail = new PHPMailer();
//Set mailer to use smtp
	$mail->isSMTP();
//Define smtp host
	$mail->Host = "smtp.gmail.com";
//Enable smtp authentication
	$mail->SMTPAuth = true;
//Set smtp encryption type (ssl/tls)
	$mail->SMTPSecure = "tls";
//Port to connect smtp
	$mail->Port = "587";
//Set gmail username
	$mail->Username = "noreply.stackiz@gmail.com";
//Set gmail password
	$mail->Password = "lvojgjsmjhyhmnxq";
//Email subject
	$mail->Subject = $subject;
//Set sender email
	$mail->setFrom('noreply.stackiz@gmail.com', 'Ace Ur Math');
//Enable HTML
	$mail->isHTML(true);
//Attachment
	//$mail->addAttachment('img/attachment.png');
//Email body
	$mail->Body = $message;
//Add recipient
	
	//$mail->addAddress('balakumar23591@gmail.com');
	if($to!='')
    {
        $array_to = explode(",",$to);
        foreach($array_to as $array_to)
        {
            $mail->addAddress($array_to);
        }
    }

	$mail->addReplyTo('info@stratilligent.com', 'Stratilligent');
        
    if($cc!='')
    {
        $array_cc = explode(",",$cc);
        foreach($array_cc as $array_cc)
        {
            $mail->addCC($array_cc);
        }
    }

    if($bcc!='')
    {
        $array_bcc = explode(",",$bcc);
        foreach($array_bcc as $array_bcc)
        {
            $mail->addBCC($array_bcc);
        }
    }

    if($file!=''){

        //Attachments
        $mail->addAttachment($file);         //Add attachments
        //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

    }


//Finally send email
	if ( $mail->send() ) {
		return true;
	} else{
		echo "Message could not be sent. Mailer Error: ".$mail->ErrorInfo;
	}
//Closing smtp connection
	$mail->smtpClose();

}
